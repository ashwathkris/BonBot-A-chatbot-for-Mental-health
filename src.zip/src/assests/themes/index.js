import defaultTheme from './default';

const getTheme = () => {
  return defaultTheme;
};
export default getTheme;
