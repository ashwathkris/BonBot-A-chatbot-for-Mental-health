import React, {Component} from 'react';
import '../App';

class Footer extends Component{
    render(){
        return(
            <footer className="footer">
                Created For Good
            </footer>
        );
    }
}
export default Footer;
