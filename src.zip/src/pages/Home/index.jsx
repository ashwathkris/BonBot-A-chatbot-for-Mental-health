import React from 'react';


const Home = () => {

    return (
        <>
            <h1>Home page</h1>
        </>
    )
}

export default Home;